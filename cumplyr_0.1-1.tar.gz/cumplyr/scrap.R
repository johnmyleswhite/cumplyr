  
  # This is underperforming others right now.
  # Problem may need to be much bigger to see improvement?
  g <- function()
  {
    iddply2(data,
            equality.variables = c('Name'),
            lower.bound.variables = c(),
            upper.bound.variables = c(),
            norm.ball.variables = list(),
            func = function (df) {with(df, mean(Value))})
  }
  
  h <- function()
  {
    iddply3(data,
            equality.variables = c('Name'),
            lower.bound.variables = c(),
            upper.bound.variables = c(),
            norm.ball.variables = list(),
            func = function (df) {with(df, mean(Value))})
  }
  
  # g() is broken.
  benchmarks <- benchmark(f(), h(),
                          columns = c("test", "replications", "elapsed", "relative"),
                          order = "relative",
                          replications = 10)
  benchmarks <- transform(benchmarks, Commit = commit)
  benchmarks <- transform(benchmarks, Date = date)
  benchmarks <- transform(benchmarks, ProblemSize = N)

  write.table(benchmarks, file = 'benchmarks.tsv', append = TRUE, quote = FALSE, sep = '\t', col.names = FALSE, row.names = FALSE)
}
