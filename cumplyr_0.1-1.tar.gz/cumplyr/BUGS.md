* When using factors, there's a reduction to integers that breaks things. (FIXED?)
