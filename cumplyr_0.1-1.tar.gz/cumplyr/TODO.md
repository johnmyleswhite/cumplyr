* Add error-checking?
* Need better examples and better documentation, especially of quirky "edge" cases.
* Need to confirm system works with multiple inequality constraints.
* Need to extend to lower bounds and norm balls.
* Switch over to iterators using `itertools`.
