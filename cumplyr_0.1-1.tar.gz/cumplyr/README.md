# An Extension of ddply to Overlapping Data Problems

split-apply-combine

Splits into disjoint sets.
Here, we split data into potentially overlapping, sequential sets.
This allows the calculation of cumulative quantities like running means.

The next extension after this is to extend to bounded regions about the current constraints for kernel calculations, for example.
