* Error-checking
* Good documentation
* Blog post
