library('cumddply')

rt.data <- read.csv('input_data.csv')

results <- cumddply(rt.data,
                    c('Subject', 'Block'),
                    c('Trial'),
                    function (df) {with(df, mean(RT))})

print(results)

results <- cumddply(rt.data,
                    c('Subject', 'Block'),
                    c('Trial'),
                    function (df) {with(df, data.frame(RT = RT, MeanRT = mean(RT)))})
# This doesn't work, because RT has many values in each df, whereas MeanRT is a unitary value.

tmp.env <- new.env()
assign('x', 1:3, envir = tmp.env)
assign('y', 2:4, envir = tmp.env)
cartesian_product(c('x', 'y', envir = tmp.env))
