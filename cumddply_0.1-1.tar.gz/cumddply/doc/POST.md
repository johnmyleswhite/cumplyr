# cumddply: An Extension of plyr using More Generic Splitting

For me, Hadley Wickham's real genius isn't his programming abilities (which are considerable), but his talent for discovering design patterns in statistical computing and then creating generic functions that address each of these patterns once and for all, so that the rest of us can have a new abstraction to use as an efficient, blackbox tool rather than having to write new code each time the design pattern comes up. We're more efficient programmers and the general purpose code is often better optimized, so that our programs are more efficient.

It's very rare that I find a design pattern Hadley hasn't already written code to solve: indeed, I blindly reimplemented a version of ddply long ago on my own before I learned about plyr. But I think that I've found a rare case in which I frequently have to perform a computation that plyr does not currently handle, though it's almost exactly the sort of thing that plyr does do. Before describing this pattern in general, I'll describe a specific instance.

[SHOW INPUT_DATA]

In this data set, I've had subjects in a psychology performa a task repeatedly in 2 blocks of 3 trials. For each trial, I've recorded their reaction time (RT). Now, for each subject and block separately, I want to compute the mean of all trials up to trial T. Thus, my desired output for a computation is:

[SHOW OUTPUT_DATA]

If I didn't have to consider subjects and blocks, I could write a function like cumsum called cummean and simply call that. But I need to do this cummean operation on many splits of the data and then combine results back together again. This is much work more programming work, especially when this sort of thing could be solved once and for all.

In an abstract way, the task I've described clearly falls under the rubric of split-apply-combine (and, in fact, is mentioned in the split-apply-combine paper), but it is not possible to perform this computation using plyr functions because ddply splits by equality constraints, whereas I need to split data by a mixture of equality and inequality constraints. Then I need to combine results using the sequence of upper bounds used for the iterative inequality constraints as my indices.

Of course, when seen in that way, this design pattern is an obvious extension of Hadley's split-apply-combine pattern by relaxing equalities to inequalities. There's very little depth to this, but it considerably enlarges the scope of computations that I perform that are simplified by a plyr function. Here, I provide a simple implementation of cumddply, which works as desired. It proceeds by doing the following on inputs, which are a data set, a set of equality constraints, a set of inequality constraints and a function:

* For all constraining variables, calculate the unique, sorted values taken on by that variable.
* Find Cartesian product of all unqiue, sorted values of all variables
* Iterate over elements of the Cartesian product
* Compute active constraints based on current element Cartesian product
* Find subset of data satisfying active constraints
* Compute function on this subset
* Add row of new data to results containging value of function and current element from Cartesian product
* Return results

There's an obvious extension to having inequalities operate in the opposite direction, but I don't see any value in that.
